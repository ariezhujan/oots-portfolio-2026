# Tutorial: Dari HP → GitHub → `bun run` → Vercel

Semua langkah di bawah bisa dilakukan **hanya dari HP**, memakai Chrome dan GitHub Codespaces
(alamat `...-5173.app.github.dev` di screenshot-mu menandakan kamu sudah memakainya).

> Tips Chrome HP: buka menu ⋮ → centang **Situs desktop** supaya tampilan VS Code di Codespaces lebih lega.

---

## Bagian A. Pasang file baru ke proyek

1. Buka **github.com** → repo portofoliomu → tombol hijau **Code** → tab **Codespaces** → buka codespace yang sudah ada.
2. Di panel **Explorer** (kiri), tekan lama / klik kanan area kosong → **Upload...** → pilih `oots-portfolio-overlay.zip` dari folder Download HP.
3. Buka **Terminal** (menu ☰ → Terminal → New Terminal), lalu jalankan satu per satu:

```bash
unzip -o oots-portfolio-overlay.zip
cp -r oots-portfolio-overlay/src/. src/
cp -r oots-portfolio-overlay/static/. static/
rm -rf oots-portfolio-overlay oots-portfolio-overlay.zip
```

Kalau muncul `unzip: command not found`, ganti baris pertama dengan:

```bash
python3 -m zipfile -e oots-portfolio-overlay.zip .
```

File yang berubah/baru: `src/lib/lanyard/*`, `src/lib/data.ts`, `PhotoGallery.svelte`, `Achievements.svelte`,
dan 5 gambar baru di `static/images/`.

---

## Bagian B. Jalankan dengan Bun (cek dulu sebelum online)

```bash
bun install
bun run dev -- --host
```

- Codespaces akan memunculkan notifikasi port **5173** → ketuk **Open in Browser**. (Atau buka tab **PORTS** → ikon globe.)
- Cek: kartu 3D bisa ditarik & diketuk untuk dibalik, galeri foto fotografi ada 7 foto, tab **Prestasi** ada Juara 3 Electro Fest 2026.
- Hentikan server dengan `Ctrl + C`, lalu uji versi produksi persis seperti yang dipakai Vercel:

```bash
bun run build
bun run preview -- --host
```

Kalau `build` sukses tanpa error merah, aman untuk diunggah.

---

## Bagian C. Kirim ke GitHub

```bash
git add .
git commit -m "Lanyard 3D, galeri foto baru, prestasi Electro Fest 2026"
git push
```

(Alternatif tanpa mengetik: ikon **Source Control** di kiri → tulis pesan → ✓ **Commit** → **Sync Changes**.)

> Gagal `git push`? Jalankan `git status` dan `git remote -v` untuk memastikan kamu berada di repo yang benar.
> Nama file di Linux/Vercel **peka huruf besar-kecil**: `Aldo.webp` ≠ `aldo.webp`.

---

## Bagian D. Hosting di Vercel

1. Buka **vercel.com** → **Sign Up / Log in** → **Continue with GitHub** → izinkan akses.
2. Ketuk **Add New… → Project**.
3. Pilih repo portofoliomu → **Import**.
4. Di halaman konfigurasi:
   - **Framework Preset**: harus terbaca **SvelteKit** (otomatis).
   - **Install Command**: `bun install`  ·  **Build Command**: `bun run build`
     (Vercel biasanya mendeteksi Bun dari file `bun.lock`/`bun.lockb`; isi manual hanya jika belum otomatis.)
   - **Environment Variables**: isi hanya jika proyekmu memakai file `.env` (mis. kunci layanan email untuk form kontak).
5. Ketuk **Deploy**, tunggu 1–2 menit. Selesai: kamu dapat alamat `nama-proyek.vercel.app`.

Setelah ini, **setiap `git push` otomatis memperbarui website**. Tidak perlu deploy manual lagi.

---

## Masalah umum

| Gejala | Solusi |
| --- | --- |
| Build gagal: `Cannot find package 'three'` | `bun add three` lalu commit & push lagi |
| Halaman kosong / 404 di Vercel | Pastikan Framework Preset = SvelteKit dan `@sveltejs/adapter-auto` terpasang (bawaan SvelteKit) |
| Gambar tidak muncul di Vercel tapi muncul lokal | Cek huruf besar-kecil nama file dan pastikan foldernya ikut ter-commit (`git status`) |
| Kartu 3D tidak muncul | Buka Console browser; jika WebGL tidak tersedia, website otomatis menampilkan kartu statis |
| Kartu terlalu terang/gelap | Ubah angka di blok `LOOK` paling atas `src/lib/lanyard/scene.ts` |

## Mengubah isi website

Semua teks, foto galeri, dan prestasi ada di **`src/lib/data.ts`**.
Untuk menambah foto: taruh file di `static/images/galeri/`, lalu tambahkan satu baris di daftar `gallery`.
Untuk foto potret, isi juga `w` dan `h` (ukuran asli) agar tampil utuh.
